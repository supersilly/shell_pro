#!/bin/bash
pp=`pwd`
cd /home/tom/serv/zookeeper/bin/
./zkServer.sh start
cd $pp

